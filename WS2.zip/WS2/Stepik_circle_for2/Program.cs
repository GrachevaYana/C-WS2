﻿//https://stepik.org/lesson/584904/step/5?unit=579655
for (int i = 1, j = 1; i < 5 && j < 10; i++, j++)

{
    Console.WriteLine($"{i} * {j} = {i * j}");
    //Console.WriteLine();
}
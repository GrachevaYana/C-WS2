﻿//https://stepik.org/lesson/584904/step/4?unit=579655
Console.WriteLine("Hello, World!");
//запрашиваем ввод переменной кол-ва раз умножений
Console.WriteLine("Введите число 1:");
int count = int.Parse(Console.ReadLine()!);
//начиная с какого числа будем умножать на 2
Console.WriteLine("Введите число 2:");
int startnumber = int.Parse(Console.ReadLine()!);
// задаем переменную цикла, условие и что делать с переменной
for (int i = 0; i < count; i++)
        {
            //пишем результат что должен делать цикл умножать стартовой число на 2 и выводить результат
            //затем стартовое число увеличивать на 1 и повторять цикл пока i будет меньше count
            Console.WriteLine($"{startnumber} * 2 = {startnumber * 2}");
            startnumber++;
        }

﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Привет, дорогой друг!");
Console.WriteLine("Чтобы вывести на экран рандомное число необходимо создать переменную класса Random.");
Console.WriteLine("var rnd = new Random();");
var rnd = new Random();
Console.WriteLine("var позволяет автоматически определить тип который будет в переменной.");
rnd.Next();//функция генерациии случайного числа
int b = rnd.Next(100);//переменная типа int чтобы сохранить значение случайного числа
Console.WriteLine(b);
Console.WriteLine("rnd.Next() - будет подбирать любое число от 1 до бесконечности.");
Console.WriteLine("rnd.Next(1000) - будет подбирать любое число от 1 до 1000.");
Console.WriteLine("rnd.Next(5,100) - будет подбирать любое число от 5 до 100.");



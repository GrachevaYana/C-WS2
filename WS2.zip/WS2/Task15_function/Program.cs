﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Привет, дорогой друг!");
Console.WriteLine("Напиcали программу, которая принимает на вход цифру, обозначающую день недели, и проверяет, является ли этот день выходным.");
Console.WriteLine("Примеры: 6 -> да, 7 -> да, 1 -> нет. Давай проверим?");
Console.WriteLine("Введи целочисленное число от 1 до 7: ");
int find = int.Parse(Console.ReadLine()!);//проверим является ли число 4 элементом массива и узнаем его позицию
string[] array = { "нет", "нет", "нет", "нет", "нет", "нет","да","да" };
Console.WriteLine(array[find]);


